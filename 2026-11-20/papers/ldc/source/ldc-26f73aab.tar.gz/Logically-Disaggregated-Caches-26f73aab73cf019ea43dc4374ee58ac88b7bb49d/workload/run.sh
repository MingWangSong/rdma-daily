make clean
make
./main